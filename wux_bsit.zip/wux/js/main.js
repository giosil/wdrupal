function _showMessage(msg, title, type, dlg) {
  if (dlg) {
    swal({ title: title, type: type, text: msg });
    return;
  }
  if (type === undefined || type === null || type === '' || type === 'info') {
    BSIT.notify({"state": 'info', "title" : title, "message": msg});
  } else 
  if (type == 'success') BSIT.notify({"state": 'success', "title" : title, "message": msg}); else
  if (type == 'warning') BSIT.notify({"state": 'warning', "title" : title, "message": msg}); else
  if (type == 'error') BSIT.notify({"state": 'error', "title" : title, "message": msg}); else BSIT.notify({"state": 'info', "title" : title, "message": msg});
}
function _showInfo(msg, title, dlg, f) {
  if (!title) title = "Informazioni";
  if (dlg) {
    swal({ title: title, text: msg }, f);
  }
  else {
    BSIT.notify({"state": 'info', "title" : title, "message": msg});
  }
}
function _showSuccess(msg, title, dlg) {
  if (!title) title = "Informazioni";
  if (dlg) {
    swal({ title: title, type: "success", text: msg });
  }
  else {
    BSIT.notify({"state": 'success', "title" : title, "message": msg});
  }
}
function _showWarning(msg, title, dlg) {
  if (!title) title = "Attenzione";
  if (dlg) {
    swal({ title: title, type: "warning", text: msg });
  }
  else {
    BSIT.notify({"state": 'warning', "title" : title, "message": msg});
  }
}
function _showError(msg, title, dlg) {
  if (!title) title = "Errore";
  if (dlg) {
    swal({ title: title, type: "error", text: msg });
  }
  else {
    BSIT.notify({"state": 'error', "title" : title, "message": msg});
  }
}
function _confirm(msg, f) {
  if (typeof f === 'function') {
    swal({ title: "Conferma", type: "warning", text: msg, confirmButtonText: "Si", cancelButtonText: "No", confirmButtonColor: "#dd6b55", showCancelButton: true, closeOnConfirm: true, closeOnCancel: true }, f);
  }
  else {
    return window.confirm(msg);
  }
}
function _getInput(msg, f, d) {
  if (typeof f === 'function') {
    swal({ title: "Inserisci", type: "input", inputValue: d, text: msg, showCancelButton: true }, f);
  }
  else {
    return window.prompt(msg);
  }
}