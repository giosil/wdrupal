import BSButton from 'bootstrap/js/src/button';

class Button extends BSButton {}

export { Button as default };
//# sourceMappingURL=button.js.map
