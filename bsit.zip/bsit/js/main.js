window.__PUBLIC_PATH__ = '/themes/basic/bootstrap-italia/fonts';
bootstrap.loadFonts('/themes/basic/bootstrap-italia/fonts');