window.__PUBLIC_PATH__ = '/themes/bsit/bootstrap-italia/fonts';
bootstrap.loadFonts('/themes/bsit/bootstrap-italia/fonts');