import BSCarousel from 'bootstrap/js/src/carousel';

class Carousel extends BSCarousel {}

export { Carousel as default };
//# sourceMappingURL=carousel.js.map
