import BSScrollSpy from 'bootstrap/js/src/scrollspy';

class ScrollSpy extends BSScrollSpy {}

export { ScrollSpy as default };
//# sourceMappingURL=scrollspy.js.map
