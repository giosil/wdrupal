import BSAlert from 'bootstrap/js/src/alert';

class Alert extends BSAlert {}

export { Alert as default };
//# sourceMappingURL=alert.js.map
