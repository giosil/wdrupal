import BSTooltip from 'bootstrap/js/src/tooltip';

class Tooltip extends BSTooltip {}

export { Tooltip as default };
//# sourceMappingURL=tooltip.js.map
