import BSModal from 'bootstrap/js/src/modal';

class Modal extends BSModal {}

export { Modal as default };
//# sourceMappingURL=modal.js.map
